
let loginTimeout;
let remainingTime = 60; // 60 detik batas waktu

// Menampilkan timer
function updateTimer() {
    const timerElement = document.getElementById("timer");
    if (remainingTime > 0) {
        timerElement.textContent = `Sisa waktu: ${remainingTime} detik`;
        remainingTime--;
    } else {
        timerElement.textContent = "Waktu habis! Silakan login ulang.";
        document.getElementById("loginForm").reset();
    }
}

// Fungsi untuk menangani login
function handleLogin(event) {
    event.preventDefault(); // Mencegah form dikirimkan

    const userId = document.getElementById("userId").value;
    const password = document.getElementById("password").value;

    // Validasi sederhana (Anda bisa mengganti ini dengan validasi yang lebih kompleks)
    if (userId && password) {
        alert("Login berhasil!");
        // Reset timer dan logout setelah login sukses
        clearInterval(loginTimeout);
    } else {
        alert("User ID atau Password tidak valid.");
    }
}

// Mulai timer
function startTimer() {
    loginTimeout = setInterval(updateTimer, 1000);
}

// Memulai timer saat halaman dimuat
window.onload = startTimer;
